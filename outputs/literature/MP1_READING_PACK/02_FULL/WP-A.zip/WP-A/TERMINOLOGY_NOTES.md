# Terminology Notes

- Continuum robot: retain source definitions based on continuous tangent vectors/continuous bending.
- Stiffness: record operational definition and boundary condition before comparison.
- Fibre/filament jamming and layer/laminar jamming are separate classes in M05.
- Measurand, standard uncertainty, combined standard uncertainty and expanded uncertainty retain GUM/NIST meanings.
