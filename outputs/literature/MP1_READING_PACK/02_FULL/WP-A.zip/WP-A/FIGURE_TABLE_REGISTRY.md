# Figure/Table Registry

| Paper | Locator | PDF page | Status | Use |
|---|---|---:|---|---|
| M02 | Fig. 1 | 1 | VERIFIED_FULL_TEXT | Continuum vs discrete structure context. |
| M04 | Fig. 2(a–d) | 2 | VERIFIED_FULL_TEXT | Stiffness operational definitions. |
| M05 | Fig. 8 | 10 | VERIFIED_FULL_TEXT | Fibre/filament jamming classification. |
| M05 | Fig. 10 | 11 | VERIFIED_FULL_TEXT | Layer/laminar jamming classification. |
