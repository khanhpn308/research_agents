# Equation Registry

| Paper | Locator | PDF page | Status | Scope |
|---|---|---:|---|---|
| M04 | Eqs. (1)–(4), Fig. 2 | 2 | VERIFIED_FULL_TEXT | Operational stiffness definitions under different loading/support cases. |
| M38 | Eq. (4) | 8 | VERIFIED_FULL_TEXT | Measurement model and input quantities. |
| M38 | Eqs. (10)–(13) | 18 | VERIFIED_FULL_TEXT | Combined uncertainty and covariance treatment. |
| M39 | Section 4 examples | 7 | VERIFIED_FULL_TEXT | Type B uncertainty and distribution assumptions. |
