# M04 — Paper Notes

**Title:** Variable stiffness methods of flexible robots for minimally invasive surgery: A review
**Authors/year:** Lin, Song, and Wang; 2024
**Canonical PDF:** `data/chap1-2_citations/M04__1.2024-Lin-Variable stiffness methods of flexible robots for minimally invasive surgery  a review.pdf`
**SHA-256:** `52f65769269d5fb82a7a0c9b62553d8d389f23b8dfcd1126ca7d914c8fa48d12`

## A. Research problem and objectives
Source-specific scope is recorded in the atomic records; no researcher objective is attributed to the authors.
## B. Physical system, materials, geometry and topology
See the evidence records and source locators; fields absent from the source remain NOT_REPORTED.
## C. Physical mechanism and loading
Review and guidance sources are used for scoped context and measurement method, not as substitutes for primary mechanics evidence.
## D. Mechanical model, equations, assumptions and boundary conditions
Equation/definition locators are listed in the package registries.
## E. Experimental setup and measured quantities
No experimental condition is inferred where the source is a review or metrology guide.
## F. Quantitative findings
Only explicitly reported definitions and quantities are retained.
## G. Validation, uncertainty and verification domain
All records are VERIFIED_FULL_TEXT at the cited physical page; scope limitations remain explicit.
## H. Figures, tables and equations
See EQUATION_REGISTRY.md and FIGURE_TABLE_REGISTRY.md.
## I. Author limitations and counterevidence
Operational stiffness definitions, model level, and uncertainty terminology must not be conflated across sources.
## J. Relevance to Chapter 1–2 and MP1 RQs
Supports the crosswalk-mapped sections without establishing MP1 novelty.
## K. Reading route
Read the cited page/section, then inspect the matching evidence record before writing.
## L. Unresolved evidence
Printed page values are NOT_REPORTED; equation typography should be human-checked before transcription.
