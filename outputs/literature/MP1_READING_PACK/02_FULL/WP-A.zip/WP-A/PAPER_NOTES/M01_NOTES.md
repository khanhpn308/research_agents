# M01 — Paper Notes

**Title:** Telling a Research Story: Writing a Literature Review
**Authors/year:** Christine B. Feak and John M. Swales; 2009
**Canonical PDF:** `data/chap1-2_citations/M01__Telling-a-Research Story Writing a Literature Review (Christine B. Feak, John M..pdf`
**SHA-256:** `5b498f49612dc5d612c604085f5f8266b990a42755188f7be5c036e0ec6059b0`

## A. Research problem and objectives
Source-specific scope is recorded in the atomic records; no researcher objective is attributed to the authors.
## B. Physical system, materials, geometry and topology
See the evidence records and source locators; fields absent from the source remain NOT_REPORTED.
## C. Physical mechanism and loading
Review and guidance sources are used for scoped context and measurement method, not as substitutes for primary mechanics evidence.
## D. Mechanical model, equations, assumptions and boundary conditions
Equation/definition locators are listed in the package registries.
## E. Experimental setup and measured quantities
No experimental condition is inferred where the source is a review or metrology guide.
## F. Quantitative findings
Only explicitly reported definitions and quantities are retained.
## G. Validation, uncertainty and verification domain
All records are VERIFIED_FULL_TEXT at the cited physical page; scope limitations remain explicit.
## H. Figures, tables and equations
See EQUATION_REGISTRY.md and FIGURE_TABLE_REGISTRY.md.
## I. Author limitations and counterevidence
Operational stiffness definitions, model level, and uncertainty terminology must not be conflated across sources.
## J. Relevance to Chapter 1–2 and MP1 RQs
Supports the crosswalk-mapped sections without establishing MP1 novelty.
## K. Reading route
Read the cited page/section, then inspect the matching evidence record before writing.
## L. Unresolved evidence
Printed page values are NOT_REPORTED; equation typography should be human-checked before transcription.
