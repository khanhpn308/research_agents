# WP-C locator issues

## Non-blocking

1. P0 reports printed pages as `NOT_REPORTED` for all new WP-C PDFs.
2. The following 16 anchors are normalized phrases whose literal PDF text differs because of line wrapping, OCR/symbol encoding, or bilingual glyph extraction: `M25-E06`, `M25-E11`, `M27-E24`, `M27-E16`, `M28-E15`, `M28-E16`, `M29-E01`, `M29-E03`, `M29-E04`, `M29-E06`, `M30-E01`, `M30-E04`, `M30-E05`, `M35-E11`, `M35-E37`, `M35-E53`. Their physical PDF page, source section and figure/equation locator were checked; do not treat the short anchor as a verbatim quotation.
3. M29 equation glyphs are bilingual/visually dense; p3 was rendered and equations (8)–(18) were visually confirmed. Perform a final typography check before thesis quotation.
4. M35 is an encrypted thesis PDF with text extraction limitations; section/page anchors were checked, but figure-local numbering should be confirmed visually.
5. M25/M27/M28 plotted values are configuration-specific; no digitization was performed.

## Blocking

- M23 identity mismatch remains open under `P0_M23_REMEDIATION`; no scientific locator was created.
