# M35 — Cable Vibration Considering Internal Friction

- **Canonical PDF:** `data/chap1-2_citations/M35__A5-Cable vibration considering internal friction.pdf`
- **SHA-256:** `aaad9c248c7dea248b14e986a530760646cb7dbac8a44d41b94642a583514800`
- **Identity:** `X. Liu, None; DOI/identifier: `N/A — luận văn thạc sĩ`
- **Extraction status:** `NEW_FULL_TEXT`
- **Mapped sections:** C2.4; C2.4.2; C2.5; C2.5.3
- **Evidence records:** M35-E11; M35-E16; M35-E37; M35-E53

## A. Section objective
MSc thesis model of cable vibration with curvature-dependent EI and interlayer dry friction; push-out pressure tests and comparison to published forced-vibration data.

## B. Concept and terminology notes
Continuum cable; curvature-dependent EI; interlayer radial pressure; static/kinetic friction; slip threshold; internal damping.

## C. Evidence with precise source locators
All claims below are `AUTHOR_RESULT` or `COUNTEREVIDENCE` and are anchored to the canonical PDF physical pages. The package records in `EVIDENCE_RECORDS.jsonl` carry the claim-level provenance.

- **M35-E11 (p. 11, Introduction/summary, NOT_APPLICABLE):** The thesis develops a 1-D continuum vibration model with curvature-dependent EI and dry-friction slip between helical layers. Anchor: “relative wire slippage between adjacent helical layers causes large, nonlinear variations in flexural rigidity”. Status: `VERIFIED_FULL_TEXT`.
- **M35-E16 (p. 16, Theory, Eq./Fig. 3.x):** The model uses a curvature–flexural-rigidity relation with slip thresholds set by interlayer pressure/friction; kinetic friction is neglected. Anchor: “interlayer radial pressure governs the onset of wire slip”. Status: `VERIFIED_FULL_TEXT`.
- **M35-E37 (p. 37, Numerical results, Figs. 4.x–5.x; Newmark scheme):** Free vibration shows amplitude decay while curvature exceeds the slip threshold, then a low-amplitude regime with little additional friction loss; Newmark β=0.25, γ=0.5 is used. Anchor: “damped phase with decaying amplitude and an undamped phase”. Status: `VERIFIED_FULL_TEXT`.
- **M35-E53 (p. 53, Validation/experiments, Figs. 5.4–5.5; push-out test):** Measured interlayer pressures are approximately 0.475 N/mm² (layers 1–2) and 0.053 N/mm² (layers 2–3); modeled endpoint histories agree with cited forced-vibration data within about 10%, while loop area is smaller. Anchor: “within 10%”. Status: `VERIFIED_FULL_TEXT`.

## D. Important equations and figures
Fourth-order PDE pp. 13–20; Hermite FEM/Newmark pp. 22–29; Figs. 4–5; pressure test tables pp. 58–66.

## E. Experimental and quantitative findings
Instron 4206 push-out tests; 500 N, 1 in/min; 0.3 m cantilever/1 m simply supported simulations; published forced-vibration comparison.

Quantitative findings are limited to the conditions in each record: no pressure-source/specimen-pressure conversion or constitutive behavior is inferred from a global curve.

## F. Cross-paper comparisons
This paper should be compared with M22/Pilot and M26/Pilot only on the shared observable and architecture stated in the records. M23 remains blocked. The main comparison axes are contact topology, helix/layer architecture, slip state, constitutive model level, validation independence, and measured quantity.

## G. Limitations and counterevidence
Bending only; small deformation; no torsion/tension coupling; kinetic friction omitted; pressure/contact-area approximation; proprietary CableCAD EI input.

## H. Relevance to MP1
Use for C2.4; C2.4.2; C2.5; C2.5.3. The evidence supports terminology, mechanics scope, model/measurement boundaries and falsifiable transfer questions; it does not by itself establish novelty of MP1 or equivalence to a vacuum-jammed beam.

## I. Reading route
1. Read the abstract/introduction for scope and architecture.
2. Read the cited model/setup pages and inspect the listed figures/tables.
3. Re-check the quantitative record conditions before comparing with MP1.
4. Read the limitation/counterevidence locator before using any claim in Chapter 1–2.

## J. Questions for human writing
- Which observable is actually shared with MP1: axial force, bending stiffness, M–κ, hysteresis, or damping?
- What contact topology and pressure path prevent direct transfer?
- Is validation independent, literature-based, or only a calibration/fit?
- Which stated limitation defines the transfer boundary?

## K. Unresolved evidence
Printed page numbering is `NOT_REPORTED` in P0 for these PDFs. Any equation glyph or plotted value that must be copied verbatim into the thesis should receive a final visual typography check. No novelty claim is made here.
