# M24 — A new mechanical model of short wire ropes: Theory and experimental validation

- **Canonical PDF:** `data/chap1-2_citations/M24__2025-A new mechanical model of short wire ropes Theory and experimental.pdf`
- **SHA-256:** `9f4295be2368f46bab9394f062b7f3cd8570093ed7855d2815c37c6cedc186a6`
- **Identity:** `Barsi, Carboni, and Lacarbonara, 2025; DOI/identifier: `10.1016/j.engstruct.2024.119217`
- **Extraction status:** `NEW_FULL_TEXT`
- **Mapped sections:** C1.2.1; C2.4; C2.4.2; C2.5; C2.5.5
- **Evidence records:** M24-E01; M24-E04; M24-E05; M24-E10

## A. Section objective
Analytical continuum model for short steel wire ropes; upper/lower bending stiffness bounds from stick/slip eigenstrains, validated by quasi-static bending and literature axial–torsional tests.

## B. Concept and terminology notes
Short rope; shear-deformable/Timoshenko beam; eigenstrain; perfect stick/partial stick/full slip; bending stiffness bounds; axial–torsional coupling.

## C. Evidence with precise source locators
All claims below are `AUTHOR_RESULT` or `COUNTEREVIDENCE` and are anchored to the canonical PDF physical pages. The package records in `EVIDENCE_RECORDS.jsonl` carry the claim-level provenance.

- **M24-E01 (p. 1, Abstract, NOT_APPLICABLE):** The paper presents a constitutive model for short steel wire ropes with upper/lower bending-stiffness bounds and experimental validation. Anchor: “The model aims to predict the lower and upper bounds of the bending stiffness”. Status: `VERIFIED_FULL_TEXT`.
- **M24-E04 (p. 4, Sec. 2.2, Eqs. (11), (18), (22)–(24)):** Wire strain measures contain an eigenstrain term; three kinematic states (perfect stick, partial stick, full slip) are used to represent relative sliding. Anchor: “perfect stick state, the partial stick state and the full slip state”. Status: `VERIFIED_FULL_TEXT`.
- **M24-E05 (p. 5, Sec. 3, Fig. 2–4; Table 1):** Two series of short steel ropes were tested in displacement-controlled pure bending at 0.2 Hz; cycles and lengths were varied. Anchor: “A quasi-static experimental campaign was performed”. Status: `VERIFIED_FULL_TEXT`.
- **M24-E10 (p. 10, Sec. 4.1–4.2, Figs. 9–11; Tables 3–6):** The full-slip state predicts minimum stiffness and the partial-stick state predicts maximum stiffness over the tested lengths; perfect-stick overestimates the maximum. Anchor: “full slip state and experimental confidence region”. Status: `VERIFIED_FULL_TEXT`.

## D. Important equations and figures
Eqs. (1)–(2) equilibrium; (6)–(11) wire/beam strains and eigenstrain; (18) constitutive matrix; (22)–(24) state bounds. Figs. 1–11; Tables 1–6.

## E. Experimental and quantitative findings
MTS 810 pure-bending fixture; R1/R2 AISI 304 ropes; 0.2 Hz; 10–20 cm (R1) and 7.5–27.5 cm (R2); seventh cycle used for stiffness.

Quantitative findings are limited to the conditions in each record: no pressure-source/specimen-pressure conversion or constitutive behavior is inferred from a global curve.

## F. Cross-paper comparisons
This paper should be compared with M22/Pilot and M26/Pilot only on the shared observable and architecture stated in the records. M23 remains blocked. The main comparison axes are contact topology, helix/layer architecture, slip state, constitutive model level, validation independence, and measured quantity.

## G. Limitations and counterevidence
Linearized/infinitesimal regime; simultaneous same slip state for bounds; no hysteresis-loop shape/dissipation; very short lengths and clamp uncertainty.

## H. Relevance to MP1
Use for C1.2.1; C2.4; C2.4.2; C2.5; C2.5.5. The evidence supports terminology, mechanics scope, model/measurement boundaries and falsifiable transfer questions; it does not by itself establish novelty of MP1 or equivalence to a vacuum-jammed beam.

## I. Reading route
1. Read the abstract/introduction for scope and architecture.
2. Read the cited model/setup pages and inspect the listed figures/tables.
3. Re-check the quantitative record conditions before comparing with MP1.
4. Read the limitation/counterevidence locator before using any claim in Chapter 1–2.

## J. Questions for human writing
- Which observable is actually shared with MP1: axial force, bending stiffness, M–κ, hysteresis, or damping?
- What contact topology and pressure path prevent direct transfer?
- Is validation independent, literature-based, or only a calibration/fit?
- Which stated limitation defines the transfer boundary?

## K. Unresolved evidence
Printed page numbering is `NOT_REPORTED` in P0 for these PDFs. Any equation glyph or plotted value that must be copied verbatim into the thesis should receive a final visual typography check. No novelty claim is made here.
