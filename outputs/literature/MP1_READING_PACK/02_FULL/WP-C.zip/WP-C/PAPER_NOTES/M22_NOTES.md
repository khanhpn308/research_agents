# M22 — PILOT_REUSED

- **Canonical PDF:** `data/chap1-2_citations/M22__2018-Bending Stiffness of Parallel Wire Cables.pdf`
- **SHA-256:** `9c2773e4cdfa29ee850d44206f42c1e21a658b8755fbffc164978d2a48d9d2fe`
- **Status:** `PILOT_REUSED`
- **Pilot note:** `outputs/literature/MP1_READING_PACK/02_PILOT/PAPER_NOTES/M22_NOTES.md`
- **Pilot evidence IDs:** see `EVIDENCE_INDEX.csv`

## A. Section objective
Reuse the verified Pilot extraction without creating or changing Evidence IDs.

## B. Concept and terminology notes
Pilot R1 confirmed the source identity, locators, equations and figures for this paper.

## C. Evidence with precise source locators
No new extraction. Pilot records remain the source of truth and are referenced in the package index.

## D. Important equations and figures
See Pilot equation/figure registries.

## E. Experimental and quantitative findings
See Pilot note and records.

## F. Cross-paper comparisons
Use the Pilot records with their original target sections.

## G. Limitations and counterevidence
Pilot R1 reported no blocking source mismatch; human typography checks remain non-blocking.

## H. Relevance to MP1
Retained exactly as Pilot-mapped.

## I. Reading route
Read Pilot note, then canonical PDF at the Pilot locators.

## J. Questions for human writing
Confirm equation glyphs/printed-page conventions before thesis quotation.

## K. Unresolved evidence
Pilot human-review queue items remain non-blocking.
