# M28 — Experimental-Numerical Assessment of Mechanical Behavior of Laboratory-Made Steel and NiTi Shape Memory Alloy Wire Ropes

- **Canonical PDF:** `data/chap1-2_citations/M28__2024-Experimental-Numerical Assessment of Mechanical Behavior of Laboratory-Made Steel and NiTi Shape Memory Alloy Wire Ropes.pdf`
- **SHA-256:** `1c81b2d35c0df0efefd34f244dfa023045dfc33762f78d14fae54de0b040ae65`
- **Identity:** `Narjabadifam et al., 2024; DOI/identifier: `10.3390/buildings14061567`
- **Extraction status:** `NEW_FULL_TEXT`
- **Mapped sections:** C2.4; C2.4.1; C2.4.2; C2.5.5
- **Evidence records:** M28-E01; M28-E10; M28-E15; M28-E16

## A. Section objective
Steel experiments plus ABAQUS simulations of NiTi/steel ropes under sinusoidal and scaled El Centro excitation.

## B. Concept and terminology notes
Laboratory-made steel/NiTi ropes; 3-D ABAQUS C3D8R; penalty contact; sinusoidal and El Centro; helix angle; superelastic recovery.

## C. Evidence with precise source locators
All claims below are `AUTHOR_RESULT` or `COUNTEREVIDENCE` and are anchored to the canonical PDF physical pages. The package records in `EVIDENCE_RECORDS.jsonl` carry the claim-level provenance.

- **M28-E01 (p. 1, Abstract, NOT_APPLICABLE):** The paper compares laboratory steel-rope tests with ABAQUS models and numerically evaluates NiTi rope response under cyclic and El Centro excitation. Anchor: “validation of all numerical simulations is undertaken against the experimentally observed behaviors”. Status: `VERIFIED_FULL_TEXT`.
- **M28-E10 (p. 10, Sec. 2.3–2.4, Figs. 8–13):** 3-D C3D8R solid models with hard normal contact and penalty friction (mu=0.5) were used; end nodes are kinematically coupled to axial reference points. Anchor: “ABAQUS FE software”. Status: `VERIFIED_FULL_TEXT`.
- **M28-E15 (p. 15, Results, Figs. 17–19; Table 9):** Simulated SMA peak forces at 8 mm are about 365 N (single wire), 1.09 kN (1×3), 2.40 kN (1×7), 6.01 kN (1×19), 8.1 kN (1×27), and 14 kN (7×7); unloading recovers deformation. Anchor: “SMA peak tensile force at 8 mm displacement”. Status: `VERIFIED_FULL_TEXT`.
- **M28-E16 (p. 16, Results/Conclusions, Fig. 20; El Centro table):** Increasing the helix angle of SMA wire ropes results in reduced stress and increased strain under the scaled El Centro case. Anchor: “increasing the helix angle of SMA wire ropes”. Status: `VERIFIED_FULL_TEXT`.

## D. Important equations and figures
FE/contact setup pp. 9–13; Figs. 8–20; Tables 8–11.

## E. Experimental and quantitative findings
Steel rope shake-table/cyclic tests at 0.1 Hz; numerical SMA 0.01 Hz; El Centro PGA 0.281g/0.6g; 1 mm wires.

Quantitative findings are limited to the conditions in each record: no pressure-source/specimen-pressure conversion or constitutive behavior is inferred from a global curve.

## F. Cross-paper comparisons
This paper should be compared with M22/Pilot and M26/Pilot only on the shared observable and architecture stated in the records. M23 remains blocked. The main comparison axes are contact topology, helix/layer architecture, slip state, constitutive model level, validation independence, and measured quantity.

## G. Limitations and counterevidence
SMA seismic response only numerical; single earthquake record; manual equal helix angles; fastener slip/missing data; material data unavailable.

## H. Relevance to MP1
Use for C2.4; C2.4.1; C2.4.2; C2.5.5. The evidence supports terminology, mechanics scope, model/measurement boundaries and falsifiable transfer questions; it does not by itself establish novelty of MP1 or equivalence to a vacuum-jammed beam.

## I. Reading route
1. Read the abstract/introduction for scope and architecture.
2. Read the cited model/setup pages and inspect the listed figures/tables.
3. Re-check the quantitative record conditions before comparing with MP1.
4. Read the limitation/counterevidence locator before using any claim in Chapter 1–2.

## J. Questions for human writing
- Which observable is actually shared with MP1: axial force, bending stiffness, M–κ, hysteresis, or damping?
- What contact topology and pressure path prevent direct transfer?
- Is validation independent, literature-based, or only a calibration/fit?
- Which stated limitation defines the transfer boundary?

## K. Unresolved evidence
Printed page numbering is `NOT_REPORTED` in P0 for these PDFs. Any equation glyph or plotted value that must be copied verbatim into the thesis should receive a final visual typography check. No novelty claim is made here.
