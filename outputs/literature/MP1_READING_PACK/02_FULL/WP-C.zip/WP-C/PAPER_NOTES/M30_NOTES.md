# M30 — High damping capacity with a wide temperature window in braided NiTi microfilaments

- **Canonical PDF:** `data/chap1-2_citations/M30__A7-2026-High damping capacity with a wide temperature window in braided NiTi microfilaments.pdf`
- **SHA-256:** `e8462758c39bdc7291365effe5e6cb74fb16c2a1201698e999f4ee2f4ca2840f`
- **Identity:** `Liu et al., 2026; DOI/identifier: `10.1016/j.matlet.2026.141544`
- **Extraction status:** `NEW_FULL_TEXT`
- **Mapped sections:** C2.4; C2.4.1; C2.4.2
- **Evidence records:** M30-E01; M30-E02; M30-E04; M30-E05

## A. Section objective
2026 DMA study of braided NiTi microfilaments, linking braid density/contact micro-slip to damping plateau and storage modulus.

## B. Concept and terminology notes
Braided NiTi microfilament; localized MT; inter-wire micro-slip; tanδ; storage modulus; picks per inch (ppi).

## C. Evidence with precise source locators
All claims below are `AUTHOR_RESULT` or `COUNTEREVIDENCE` and are anchored to the canonical PDF physical pages. The package records in `EVIDENCE_RECORDS.jsonl` carry the claim-level provenance.

- **M30-E01 (p. 1, Abstract/Introduction, Fig. 1):** Braided NiTi microfilaments combine localized martensitic transformation, structural deformation and inter-wire micro-sliding to broaden damping. Anchor: “NiTi microfilaments introducing sequential localized phase transformations”. Status: `VERIFIED_FULL_TEXT`.
- **M30-E02 (p. 2, Experimental, Fig. 2):** DMA tests used 20 μm fixed amplitude, 1/5 Hz and 5 °C/min over −70 to 75 °C; 8B/88B morphologies and ten thermal cycles were recorded. Anchor: “TA Q850 dynamic mechanical analyzer”. Status: `VERIFIED_FULL_TEXT`.
- **M30-E04 (p. 4, Results/Conclusion, Figs. 2–4):** 8B has tanδ about 0.02–0.05 and storage modulus 11–12 GPa; 88B reaches tanδ 0.06–0.11 and storage modulus about 3.6–4.3 GPa over >145 °C; 1/5 Hz curves nearly overlap. Anchor: “the tanδ of 8B-NiTi remains stable at 0.02–0.05”. Status: `VERIFIED_FULL_TEXT`.
- **M30-E05 (p. 4, Results/Conclusion, Figs. 3–4):** Increasing wire count raises tanδ (4B 0.008–0.02; 12B 0.03–0.06), while ppi80 tight constraint reduces tanδ to 0.02–0.04 despite more contacts; ppi25 retains a ~0.10 peak near −20 °C. Anchor: “shortening the micro-slip displacement at the contact sites”. Status: `VERIFIED_FULL_TEXT`.

## D. Important equations and figures
No governing constitutive equation; Figs. 1–4 and supplementary cycling/tensile figures.

## E. Experimental and quantitative findings
TA Q850 DMA, 20 μm, 1/5 Hz, 5 °C/min, −70–75 °C; 4B/8B/12B at 50 ppi; 8B ppi25/50/80; 88B double braid.

Quantitative findings are limited to the conditions in each record: no pressure-source/specimen-pressure conversion or constitutive behavior is inferred from a global curve.

## F. Cross-paper comparisons
This paper should be compared with M22/Pilot and M26/Pilot only on the shared observable and architecture stated in the records. M23 remains blocked. The main comparison axes are contact topology, helix/layer architecture, slip state, constitutive model level, validation independence, and measured quantity.

## G. Limitations and counterevidence
Small-amplitude passive DMA; no large bending/robot integration/model/fatigue; ppi80 trade-off reduces micro-slip.

## H. Relevance to MP1
Use for C2.4; C2.4.1; C2.4.2. The evidence supports terminology, mechanics scope, model/measurement boundaries and falsifiable transfer questions; it does not by itself establish novelty of MP1 or equivalence to a vacuum-jammed beam.

## I. Reading route
1. Read the abstract/introduction for scope and architecture.
2. Read the cited model/setup pages and inspect the listed figures/tables.
3. Re-check the quantitative record conditions before comparing with MP1.
4. Read the limitation/counterevidence locator before using any claim in Chapter 1–2.

## J. Questions for human writing
- Which observable is actually shared with MP1: axial force, bending stiffness, M–κ, hysteresis, or damping?
- What contact topology and pressure path prevent direct transfer?
- Is validation independent, literature-based, or only a calibration/fit?
- Which stated limitation defines the transfer boundary?

## K. Unresolved evidence
Printed page numbering is `NOT_REPORTED` in P0 for these PDFs. Any equation glyph or plotted value that must be copied verbatim into the thesis should receive a final visual typography check. No novelty claim is made here.
