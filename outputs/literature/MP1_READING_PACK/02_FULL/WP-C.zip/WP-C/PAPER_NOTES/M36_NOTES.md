# M36 — Nonlinear Vibration Absorber with Pinched Hysteresis: Theory and Experiments

- **Canonical PDF:** `data/chap1-2_citations/M36__2016-Nonlinear Vibration Absorber with Pinched Hysteresis Theory and Experiments.pdf`
- **SHA-256:** `40760daa02b35309d91df1f6aadf35cf34726dc98d8e9520f1324e23cc59a4b3`
- **Identity:** `Carboni and Lacarbonara, 2016; DOI/identifier: `10.1061/(ASCE`
- **Extraction status:** `NEW_FULL_TEXT`
- **Mapped sections:** C2.4; C2.4.1; C2.4.2; C2.5; C2.5.3
- **Evidence records:** M36-E01; M36-E04; M36-E10; M36-E19

## A. Section objective
Mixed NiTiNOL–steel wire-rope TMD with phenomenological Bouc–Wen pinched hysteresis, optimization and shaking-table validation.

## B. Concept and terminology notes
Mixed NiTiNOL–steel rope; cyclic bending; pinched hysteresis; modified Bouc–Wen; DE optimization; equivalent damping.

## C. Evidence with precise source locators
All claims below are `AUTHOR_RESULT` or `COUNTEREVIDENCE` and are anchored to the canonical PDF physical pages. The package records in `EVIDENCE_RECORDS.jsonl` carry the claim-level provenance.

- **M36-E01 (p. 1, Abstract, NOT_APPLICABLE):** A passive absorber uses mixed NiTiNOL–steel rope bending; interwire friction plus phase transformation produces pinched hysteresis. Anchor: “mixed wire ropes are assembled in a mechanical device”. Status: `VERIFIED_FULL_TEXT`.
- **M36-E04 (p. 4, Quasi-static characterization, Fig. 2–5; Eqs. (1)–(7)):** Quasi-static MTS tests at 0.066 Hz characterize restoring-force loops; a modified Bouc–Wen model with exponential pinching is identified by differential evolution. Anchor: “The equivalent damping ratio, associated with experimental”. Status: `VERIFIED_FULL_TEXT`.
- **M36-E10 (p. 10, Optimization, Fig. 10–14; FRCs):** After optimization, equivalent damping and resonance frequency become nearly constant over a displacement-amplitude range, with slight detuning at lower excitations. Anchor: “pinched hysteresis provides an equivalent damping ratio and resonance frequency”. Status: `VERIFIED_FULL_TEXT`.
- **M36-E19 (p. 19, Shaking-table validation, Figs. 21–27; Tables 7–9):** Five-storey scaled-frame tests with the TMD report top-floor displacement reductions of about 38.32–69.12% and acceleration reductions of about 39.08–72.13% for 0.023–0.045g base inputs. Anchor: “comparison between controlled and uncontrolled responses”. Status: `VERIFIED_FULL_TEXT`.

## D. Important equations and figures
Modified Bouc–Wen and absorber Eqs. (1)–(19); Figs. 2–27; Tables 1–9.

## E. Experimental and quantitative findings
MTS 0.066 Hz quasi-static tests; four NiTi-ST61 ropes; shaking-table 5-storey 677 kg frame; 0.023–0.045g.

Quantitative findings are limited to the conditions in each record: no pressure-source/specimen-pressure conversion or constitutive behavior is inferred from a global curve.

## F. Cross-paper comparisons
This paper should be compared with M22/Pilot and M26/Pilot only on the shared observable and architecture stated in the records. M23 remains blocked. The main comparison axes are contact topology, helix/layer architecture, slip state, constitutive model level, validation independence, and measured quantity.

## G. Limitations and counterevidence
Phenomenological fit; low-level detuning; guide rolling friction; one parameter set; unidirectional/harmonic validation; no fatigue/temp sweep.

## H. Relevance to MP1
Use for C2.4; C2.4.1; C2.4.2; C2.5; C2.5.3. The evidence supports terminology, mechanics scope, model/measurement boundaries and falsifiable transfer questions; it does not by itself establish novelty of MP1 or equivalence to a vacuum-jammed beam.

## I. Reading route
1. Read the abstract/introduction for scope and architecture.
2. Read the cited model/setup pages and inspect the listed figures/tables.
3. Re-check the quantitative record conditions before comparing with MP1.
4. Read the limitation/counterevidence locator before using any claim in Chapter 1–2.

## J. Questions for human writing
- Which observable is actually shared with MP1: axial force, bending stiffness, M–κ, hysteresis, or damping?
- What contact topology and pressure path prevent direct transfer?
- Is validation independent, literature-based, or only a calibration/fit?
- Which stated limitation defines the transfer boundary?

## K. Unresolved evidence
Printed page numbering is `NOT_REPORTED` in P0 for these PDFs. Any equation glyph or plotted value that must be copied verbatim into the thesis should receive a final visual typography check. No novelty claim is made here.
