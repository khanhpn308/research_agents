# M29 — Finite Element Method for Mechanical Behavior of Shape Memory Alloy Superelastic Cables

- **Canonical PDF:** `data/chap1-2_citations/M29__2025-Finite Element Method for Mechanical Behavior of Shape Memory Alloy .pdf`
- **SHA-256:** `56793dea9b3dcbb4224e7c61297f37983f9ff0abcf43d1d782c0e0ad26355b61`
- **Identity:** `Kang, Wang, Zhou, and Xue, 2020; DOI/identifier: `10.3901/JME.2020.14.065`
- **Extraction status:** `NEW_FULL_TEXT`
- **Mapped sections:** C2.4; C2.4.1; C2.4.2; C2.5.5
- **Evidence records:** M29-E01; M29-E03; M29-E04; M29-E06

## A. Section objective
Chinese/English FE paper deriving an incremental SMA UMAT and studying pitch/contact effects in a 7×7 cable.

## B. Concept and terminology notes
Incremental SMA constitutive law; shape-memory factor; UMAT; 7×7 cable; frictionless contact; outer pitch.

## C. Evidence with precise source locators
All claims below are `AUTHOR_RESULT` or `COUNTEREVIDENCE` and are anchored to the canonical PDF physical pages. The package records in `EVIDENCE_RECORDS.jsonl` carry the claim-level provenance.

- **M29-E01 (p. 1, Abstract, NOT_APPLICABLE):** The Chinese/English abstract states that coupled material/contact nonlinearities motivate an incremental SMA constitutive FE method in ABAQUS. Anchor: “很难建立描述形状记忆合金(Shape memory alloy，SMA)超弹性缆索力学行为的理论模型”. Status: `VERIFIED_FULL_TEXT`.
- **M29-E03 (p. 3, Constitutive formulation, Eqs. (1)–(12)):** The incremental strain decomposition and shape-memory-factor constitutive update are implemented as a UMAT with phase-dependent elastic modulus. Anchor: “dεij = dεijtr + dεijth + dεije”. Status: `VERIFIED_FULL_TEXT`.
- **M29-E04 (p. 4, Validation, Figs. 3–8; Tables 1–2):** For simplified cross-sections, simulated core-strand start/finish stresses are about 486.5/518.9 MPa (configuration a) and 493.7/526.1 MPa (b), within roughly 1.5–4.1% for forward-start/finish comparisons; reverse values show larger errors. Anchor: “martensitic transformation start and finish stresses”. Status: `VERIFIED_FULL_TEXT`.
- **M29-E06 (p. 6, Parametric analysis, Figs. 11–13):** Contact regions between core and outer strands concentrate stress; increasing outer pitch from 40 to 50/60 mm lowers nominal stress, transformation stresses and initial moduli. Anchor: “frictionless smooth contact was assumed”. Status: `VERIFIED_FULL_TEXT`.

## D. Important equations and figures
Eqs. (1)–(12) incremental constitutive update; Figs. 1–13; Tables 1–2.

## E. Experimental and quantitative findings
20 mm, 49-wire 0.885 mm cable; 25 °C; comparison with Mas et al. literature tensile data; rigid cylindrical fixtures.

Quantitative findings are limited to the conditions in each record: no pressure-source/specimen-pressure conversion or constitutive behavior is inferred from a global curve.

## F. Cross-paper comparisons
This paper should be compared with M22/Pilot and M26/Pilot only on the shared observable and architecture stated in the records. M23 remains blocked. The main comparison axes are contact topology, helix/layer architecture, slip state, constitutive model level, validation independence, and measured quantity.

## G. Limitations and counterevidence
Frictionless contact underestimates nominal stress; simplified cross-section; no frictional load transfer or fretting.

## H. Relevance to MP1
Use for C2.4; C2.4.1; C2.4.2; C2.5.5. The evidence supports terminology, mechanics scope, model/measurement boundaries and falsifiable transfer questions; it does not by itself establish novelty of MP1 or equivalence to a vacuum-jammed beam.

## I. Reading route
1. Read the abstract/introduction for scope and architecture.
2. Read the cited model/setup pages and inspect the listed figures/tables.
3. Re-check the quantitative record conditions before comparing with MP1.
4. Read the limitation/counterevidence locator before using any claim in Chapter 1–2.

## J. Questions for human writing
- Which observable is actually shared with MP1: axial force, bending stiffness, M–κ, hysteresis, or damping?
- What contact topology and pressure path prevent direct transfer?
- Is validation independent, literature-based, or only a calibration/fit?
- Which stated limitation defines the transfer boundary?

## K. Unresolved evidence
Printed page numbering is `NOT_REPORTED` in P0 for these PDFs. Any equation glyph or plotted value that must be copied verbatim into the thesis should receive a final visual typography check. No novelty claim is made here.
