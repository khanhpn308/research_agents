# M25 — Mechanical response of single and double-helix SMA wire ropes

- **Canonical PDF:** `data/chap1-2_citations/M25__A3-2022-Mechanical response of single and double-helix.pdf`
- **SHA-256:** `53200aa0c608c3ff3b7819b6c17bc87a79f236ac4e8ff4b1c69e3c5d7cbfed1a`
- **Identity:** `Vahidi, Arghavani, Choi, and Ostadrahimi, 2021; DOI/identifier: `10.1080/15376494.2021.1955313`
- **Extraction status:** `NEW_FULL_TEXT`
- **Mapped sections:** C2.4; C2.4.1; C2.4.2; C2.5; C2.5.5
- **Evidence records:** M25-E02; M25-E04; M25-E06; M25-E11

## A. Section objective
Implicit Abaqus/UMAT study of 1×27 and 7×7 SMA ropes with helical contact/friction, superelastic and SME responses, and specific-energy optimization.

## B. Concept and terminology notes
SMA superelasticity/SME; 1×27 single helix; 7×7 double helix; UMAT; Coulomb contact; helix angle; normal/shear stress and torque.

## C. Evidence with precise source locators
All claims below are `AUTHOR_RESULT` or `COUNTEREVIDENCE` and are anchored to the canonical PDF physical pages. The package records in `EVIDENCE_RECORDS.jsonl` carry the claim-level provenance.

- **M25-E02 (p. 3, Introduction / model description, Fig. 1–3):** The study uses implicit Abaqus FE with a 3-D phenomenological SMA constitutive model and explicit interwire contact/friction for single- and double-helix ropes. Anchor: “Due to the convoluted geometry and interwire contact status within a cable”. Status: `VERIFIED_FULL_TEXT`.
- **M25-E04 (p. 4, Sec. 2–3, Fig. 3; Eqs. (1)–(6)):** Helix geometry and lay direction govern normal/shear stress and torque distributions; shear sign follows lay direction. Anchor: “helix angle”. Status: `VERIFIED_FULL_TEXT`.
- **M25-E06 (p. 6, Validation, Table/Figs. 5–10):** SMA rope simulations reproduce published experimental trends with average normal/shear stress deviations of about 20–25%. Anchor: “matching experimental stress-strain trends”. Status: `VERIFIED_FULL_TEXT`.
- **M25-E11 (p. 11, Optimization, Table 6; response surface):** The response-surface analysis reports higher specific energy for larger wire diameter and smaller helix angle. Anchor: “specific energy increases with larger wire diameter and smaller helix angle”. Status: `VERIFIED_FULL_TEXT`.

## D. Important equations and figures
FE constitutive equations/UMAT and helical geometry in pp. 3–6; Figs. 5–14 and Tables 5–6.

## E. Experimental and quantitative findings
No new physical experiment; implicit Abaqus simulations validated against Reedlunn/Stanova data; 25 °C SE and prescribed SME thermal recovery.

Quantitative findings are limited to the conditions in each record: no pressure-source/specimen-pressure conversion or constitutive behavior is inferred from a global curve.

## F. Cross-paper comparisons
This paper should be compared with M22/Pilot and M26/Pilot only on the shared observable and architecture stated in the records. M23 remains blocked. The main comparison axes are contact topology, helix/layer architecture, slip state, constitutive model level, validation independence, and measured quantity.

## G. Limitations and counterevidence
20–25% stress deviations; computationally expensive implicit solve; end-clamp rotation and tension-compression asymmetry simplified; no independent experiment.

## H. Relevance to MP1
Use for C2.4; C2.4.1; C2.4.2; C2.5; C2.5.5. The evidence supports terminology, mechanics scope, model/measurement boundaries and falsifiable transfer questions; it does not by itself establish novelty of MP1 or equivalence to a vacuum-jammed beam.

## I. Reading route
1. Read the abstract/introduction for scope and architecture.
2. Read the cited model/setup pages and inspect the listed figures/tables.
3. Re-check the quantitative record conditions before comparing with MP1.
4. Read the limitation/counterevidence locator before using any claim in Chapter 1–2.

## J. Questions for human writing
- Which observable is actually shared with MP1: axial force, bending stiffness, M–κ, hysteresis, or damping?
- What contact topology and pressure path prevent direct transfer?
- Is validation independent, literature-based, or only a calibration/fit?
- Which stated limitation defines the transfer boundary?

## K. Unresolved evidence
Printed page numbering is `NOT_REPORTED` in P0 for these PDFs. Any equation glyph or plotted value that must be copied verbatim into the thesis should receive a final visual typography check. No novelty claim is made here.
