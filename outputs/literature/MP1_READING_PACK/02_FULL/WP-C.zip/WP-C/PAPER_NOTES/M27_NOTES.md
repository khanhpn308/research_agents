# M27 — Superelastic Shape Memory Alloy Cables: Part II – Subcomponent Isothermal Responses

- **Canonical PDF:** `data/chap1-2_citations/M27__2013-Superelastic shape memory alloy cables Part II – Subcomponent isothermal responses.pdf`
- **SHA-256:** `fac21c950ecbe7dcc0ef246a6cf958186112529fc3f98be8241fb81d0dc7a284`
- **Identity:** `Reedlunn, Daly, and Shaw, 2013; DOI/identifier: `10.1016/j.ijsolstr.2013.03.015`
- **Extraction status:** `NEW_FULL_TEXT`
- **Mapped sections:** C2.4; C2.4.1; C2.4.2; C2.5.5
- **Evidence records:** M27-E02; M27-E08; M27-E13; M27-E24; M27-E16

## A. Section objective
Experimental decomposition of 7×7 and 1×27 NiTi cable responses into wires/layers under slow tension, with DIC/IR/torque and response subtraction.

## B. Concept and terminology notes
7×7 right regular lay; 1×27 alternating lay; hierarchical subcomponents; transformation fronts; DIC/IR; reaction torque; layer subtraction.

## C. Evidence with precise source locators
All claims below are `AUTHOR_RESULT` or `COUNTEREVIDENCE` and are anchored to the canonical PDF physical pages. The package records in `EVIDENCE_RECORDS.jsonl` carry the claim-level provenance.

- **M27-E02 (p. 2, Abstract, NOT_APPLICABLE):** Hierarchical subcomponents of 7×7 and 1×27 superelastic NiTi cables were tested; 7×7 components behave close to parallel wires, while 1×27 becomes more compliant with added layers. Anchor: “force-elongation responses of the core wire, 1×7 core strand and full 7×7 cable were similar”. Status: `VERIFIED_FULL_TEXT`.
- **M27-E08 (p. 8, Sec. 3, Figs. 2–4):** For 7×7 components, loading plateau stress decreases only slightly from about 517 MPa (core wire) to 506 MPa (1×7 strand); transformation fronts propagate. Anchor: “slight decrease in transformation force plateaus”. Status: `VERIFIED_FULL_TEXT`.
- **M27-E13 (p. 13, Sec. 4, Figs. 5–10):** Adding outer layers to 1×27 reduces secant modulus (about 23.7 to 7.3 GPa) and raises failure strain to roughly 40%; fronts are absent and localization is distributed around manufacturing indentations. Anchor: “no propagating transformation fronts”. Status: `VERIFIED_FULL_TEXT`.
- **M27-E24 (p. 24, Sec. 5, Figs. 13–20):** Subcomponent subtraction identifies layer contributions; R+→M+ initiation occurs at approximately 2.2% (layer B), 6.0% (C), and 8.8% (D). Anchor: “inner layers transform prior to outer layers”. Status: `VERIFIED_FULL_TEXT`.
- **M27-E16 (p. 16, Analytical comparison, Eq./Fig. 8–10):** Simple uniaxial predictions work for shallow-helix 1×7 but overpredict plateau stress for steeper 1×6 because local wire bending/twisting are omitted. Anchor: “local bending and twisting are omitted”. Status: `VERIFIED_FULL_TEXT`.

## D. Important equations and figures
Analytical helix-angle plateau/torque relations and Biot-number check; Figs. 2–20; Tables 1–4.

## E. Experimental and quantitative findings
Displacement-controlled quasi-static tension; 18–22 °C; rates 10⁻⁵ s⁻¹ (7×7) and 10⁻⁴ s⁻¹ (1×27); rigid zero-rotation grips; ~50 mm gauge.

Quantitative findings are limited to the conditions in each record: no pressure-source/specimen-pressure conversion or constitutive behavior is inferred from a global curve.

## F. Cross-paper comparisons
This paper should be compared with M22/Pilot and M26/Pilot only on the shared observable and architecture stated in the records. M23 remains blocked. The main comparison axes are contact topology, helix/layer architecture, slip state, constitutive model level, validation independence, and measured quantity.

## G. Limitations and counterevidence
Grip fractures and field-of-view/IR limits; subtraction magnifies error; uniaxial/isothermal scope; steep-helix local bending/twist omitted by simple model.

## H. Relevance to MP1
Use for C2.4; C2.4.1; C2.4.2; C2.5.5. The evidence supports terminology, mechanics scope, model/measurement boundaries and falsifiable transfer questions; it does not by itself establish novelty of MP1 or equivalence to a vacuum-jammed beam.

## I. Reading route
1. Read the abstract/introduction for scope and architecture.
2. Read the cited model/setup pages and inspect the listed figures/tables.
3. Re-check the quantitative record conditions before comparing with MP1.
4. Read the limitation/counterevidence locator before using any claim in Chapter 1–2.

## J. Questions for human writing
- Which observable is actually shared with MP1: axial force, bending stiffness, M–κ, hysteresis, or damping?
- What contact topology and pressure path prevent direct transfer?
- Is validation independent, literature-based, or only a calibration/fit?
- Which stated limitation defines the transfer boundary?

## K. Unresolved evidence
Printed page numbering is `NOT_REPORTED` in P0 for these PDFs. Any equation glyph or plotted value that must be copied verbatim into the thesis should receive a final visual typography check. No novelty claim is made here.
